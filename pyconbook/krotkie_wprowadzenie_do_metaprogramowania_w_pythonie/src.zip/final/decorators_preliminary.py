def debug_wrapper(func): 
    msg = func.__name__ 
    def wrapper(*args, **kwargs):
        print(msg)
        return func(*args, **kwargs) 
    return wrapper

def add(x,y):
    return x + y

if __name__ == '__main__':
    debug_add = debug_wrapper(add)
    debug_add(1,1) # <-- OK
    print debug_add.__name__, debug_add.__doc__, debug_add.__module__ # <-- FIXME
    
