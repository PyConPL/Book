# -*- coding: utf-8 -*-
class Spam(object):
    pass

o = Spam() #obiekt klasy Spam
print o

print Spam #klasa jest obiektem który może tworzyć obiekty (instancje) klasy

def foo(a): print a

foo(Spam) # klasę można przekazać jako argument
Spam.cos_nowego = 'bar' # można przypisać do klasy atrybut
Spam2 = Spam # przypisać klasę do zmiennej
print Spam2()

print type(1) #<type 'int'>
print type("1") #<type 'str'>
print type(Spam()) #<class '__main__.Spam'>
print type(Spam) #<type 'type'>

def napisz_cos(self): print self.cos_nowego
NowySpam = type('NowySpam', (), {'cos_nowego':True, 'napisz_cos':napisz_cos})
print NowySpam
a = NowySpam()
print a
a.napisz_cos()
class NowySpam2(NowySpam): pass
b = NowySpam2()
b.napisz_cos()
