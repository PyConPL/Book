from functools import wraps

def debug(prefix=''):
    def decorate(func): 
        msg = prefix + func.__name__ 
        @wraps(func) 
        def wrapper(*args, **kwargs):
            print(msg)
            return func(*args, **kwargs) 
        return wrapper
    return decorate

@debug(prefix='****') # <-- OK
def add(x, y):
    return x + y

@debug # <-- ERROR
def add1(x, y): 
    return x + y

if __name__ == '__main__':
    add(1, 2)
    add1(1, 2)
