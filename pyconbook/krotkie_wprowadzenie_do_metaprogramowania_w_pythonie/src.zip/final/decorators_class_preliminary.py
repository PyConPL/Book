from functools import wraps, partial

def debug(func=None, prefix=''): 
    if func is None:
        return partial(debug, prefix=prefix)
    msg = prefix + func.__name__ 
    @wraps(func) 
    def wrapper(*args, **kwargs):
        print(msg)
        return func(*args, **kwargs) 
    return wrapper

class Spam(object):
    @debug
    def __init__(self): pass

    @debug
    def add(self, a, b):
        return a+b 

if __name__ == '__main__':
    a = Spam()
    a.add(1, 2)
    a.name = "test"
