def debug_wrapper(func): 
    msg = func.__name__ 
    def wrapper(*args, **kwargs):
        print(msg)
        return func(*args, **kwargs) 
    return wrapper

@debug_wrapper
def add(x, y):
    return x + y

if __name__ == '__main__':
    add(1, 1)
