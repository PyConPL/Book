from functools import wraps, partial

def debug(func=None, prefix=''): 
    if func is None:
        return partial(debug, prefix=prefix)
    msg = prefix + func.__name__ 
    @wraps(func) 
    def wrapper(*args, **kwargs):
        print(msg)
        return func(*args, **kwargs) 
    return wrapper

def debugattr(cls): 
    orig_getattribute = cls.__getattribute__
    def __getattribute__(self, name): 
        print('Get:', name) 
        return orig_getattribute(self, name)
    cls.__getattribute__ = __getattribute__
    return cls

def debugmethods(cls): 
    prefix = "*** %s." %(cls.__name__,)
    for name, val in vars(cls).items():
        if callable(val): 
            setattr(cls, name, debug(val, prefix)) # debug zdefiniowane wcześniej
    return cls

@debugmethods
@debugattr
class Spam(object):
    def __init__(self):
        self.name = ""
        pass

    def add(self, a, b):
        return a+b 

if __name__ == '__main__':
    a = Spam()
    a.add(1, 2)
    a.name = "test"
