d = {} # nasz nowy namespace
exec "def spam(x): return x" in d
spam = d['spam']
print spam(1)


d = {}
exec """def spam(self): print 'spam'\n
def morespam(self): print 'morespam'
""" in d
SyntetycznaKlasa = type('SyntetycznyKlasa', (), d)
s = SyntetycznaKlasa()
s.spam()
s.morespam()


import new,sys

nowy_modul = new.module('SyntetycznyModul', 'Opis')
nowy_modul.SyntetycznaKlasa = SyntetycznaKlasa
sys.modules['SyntetycznyModul'] = nowy_modul

del new, sys, nowy_modul, SyntetycznaKlasa

import SyntetycznyModul

s = SyntetycznyModul.SyntetycznaKlasa()
s.spam()
s.morespam()



