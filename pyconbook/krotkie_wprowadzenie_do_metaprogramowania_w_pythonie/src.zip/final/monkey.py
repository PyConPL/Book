import types
class Spam(object):
    def __init__(self):
        self.x = "X"
        
    def foo(self):
        print "stara metoda", self.x

def foo2(self):
    print "nowa metoda", self.x

Spam.foo = types.MethodType(foo2, None, Spam)
s1 = Spam()
s1.foo() # <-- "nowa metoda"


def foo3(self):
    print "kolejna metoda", self.x

s2 = Spam()
s2.foo = types.MethodType(foo3, s2, Spam)

s1.foo() # <-- "nowa metoda"
s2.foo() # <-- "kolejna metoda"
