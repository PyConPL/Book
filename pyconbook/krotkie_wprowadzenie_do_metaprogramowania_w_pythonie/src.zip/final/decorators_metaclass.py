from functools import wraps, partial
def debug(func=None, prefix=''): 
    if func is None:
        return partial(debug, prefix=prefix)
    msg = prefix + func.__name__ 
    @wraps(func) 
    def wrapper(*args, **kwargs):
        print(msg)
        return func(*args, **kwargs) 
    return wrapper

def debugattr(cls): 
    orig_getattribute = cls.__getattribute__
    def __getattribute__(self, name): 
        print('Get:', name) 
        return orig_getattribute(self, name)
    cls.__getattribute__ = __getattribute__
    return cls

def debugmethods(cls): 
    for name, val in vars(cls).items():
        if callable(val): 
            setattr(cls, name, debug(val))
    return cls

class debugmeta(type): 
    def __new__(cls, clsname, bases, clsdict):
        clsobj = super(cls, cls).__new__(cls, clsname, bases, clsdict)
        clsobj = debugmethods(clsobj) 
        clsobj = debugattr(clsobj)
        return clsobj

class Spam(object):
    __metaclass__ = debugmeta 
    """docstring for Spamm"""
    def __init__(self):
        pass

    def add(self, a, b):
        return a+b 

class SpamChild(Spam):
    pass

if __name__ == '__main__':
    s = SpamChild()
    s.add(1, 2)

