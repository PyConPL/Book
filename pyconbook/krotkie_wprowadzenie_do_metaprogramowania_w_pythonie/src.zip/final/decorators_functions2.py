from functools import wraps
def debug_wrapper(func): 
    msg = func.__name__ 
    @wraps(func) 
    def wrapper(*args, **kwargs):
        print(msg)
        return func(*args, **kwargs) 
    return wrapper

@debug_wrapper
def add(x, y):
    return x + y

if __name__ == '__main__':
    add(1, 1) # <-- OK
    print add.__name__, add.__doc__, add.__module__ # <-- OK
