from functools import wraps, partial

def debug(func=None, prefix=''): 
    if func is None:
        return partial(debug, prefix=prefix)
    msg = prefix + func.__name__ 
    @wraps(func) 
    def wrapper(*args, **kwargs):
        print(msg)
        return func(*args, **kwargs) 
    return wrapper

@debug(prefix='****') # <-- OK
def add(x, y):
    return x + y

@debug # <-- OK
def add1(x, y): 
    return x + y

if __name__ == '__main__':
    add(1, 2)
    add1(1, 2)
